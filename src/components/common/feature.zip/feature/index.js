import feature from './feature.vue'
import featureitem from './featureItem.vue'
export {
         feature,
         featureitem
}